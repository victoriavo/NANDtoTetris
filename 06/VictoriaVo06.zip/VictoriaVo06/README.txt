I ran my program via the terminal command line. 

After getting to the directory where the files are stored,

ex: 

cd ~/documents/nand2tetris/projects/06

the command line prompt is 

g++ -std=c++11 main.cpp parser.h parser.cpp symbolTable.cpp symbolTable.h code.h code.cpp

./a.out max/Max.asm
./a.out add/Add.asm

As of now, Add.asm outputs correctly and Max.asm outputs correctly except for the symbols. 